<template>
    
</template>

<script>
    export default {
        name: "productionSubject"
    }
</script>

<style scoped>

</style>