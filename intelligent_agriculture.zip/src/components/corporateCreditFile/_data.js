export default [
  {
    creditGradeId: "1",
    creditCode: "ASSADAS...",
    approvalGrade: "稻米专业合作社",
    originalGrade: "B级（基本守信）",
    nowGrade: "A级（守信）",
    gradeTime: "2019-08-03 12:32:43",
    gradeUnit: "梅李镇农产品质量安全监管站",
    approvalStatus: "待审批",
  },
]
