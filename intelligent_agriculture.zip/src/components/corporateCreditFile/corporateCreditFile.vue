<template>
  <div class="container">
    <div class="title">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">企业信用档案</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="box">
      <div class="iptBox">
        <div class="select_label">乡镇</div>
        <el-select v-model="currTown" placeholder="请选择" @change="getList()">
          <el-option v-for="item in township" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
        <div class="select_label">类型</div>
        <el-radio v-model="bTypes" label="1" v-on:change="getList(true)">企业</el-radio>
        <el-radio v-model="bTypes" label="2" v-on:change="getList(true)">农户</el-radio>
        <div class="select_label">行政许可</div>
        <el-select v-model="public_license" placeholder="请选择" @change="onSelectPubLicense">
          <el-option
            v-for="item in publicOptions"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
        <div class="select_label">行政处罚</div>
        <el-select v-model="public_punish" placeholder="请选择" @change="onSelectPubPunish">
          <el-option
            v-for="item in publicOptions"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
        <div class="select_label" v-if="loggedinUserType !== 3">
          <el-button type="outline-primary" v-on:click="getList()" disabled>导入</el-button>
        </div>
      </div>

      <el-container>
        <el-table
          :data="tableData"
          v-loading="listLoading"
          fit
          style="width: 100%;"
          :row-class-name="rowIndex"
          highlight-current-row
        >
          <el-table-column :formatter="order" label="序号" width="70"></el-table-column>
          <el-table-column
            label="企业名称"
            width="150"
            v-if="loggedinUserType ===2 || loggedinUserType === 0"
          >
            <template slot-scope="{row}">{{filterCompnay(row.creditCode)}}</template>
          </el-table-column>
          <el-table-column label="名称" width="150" v-if="loggedinUserType !==2">
            <template slot-scope="{row}">{{filterCompnay(row.creditCode)}}</template>
          </el-table-column>
          <el-table-column
            prop="creditCode"
            label="统一社会信用代码"
            v-if="loggedinUserType ===2 || loggedinUserType === 0"
          ></el-table-column>
          <el-table-column prop="creditCode" label="信用代码" v-if="loggedinUserType !==2"></el-table-column>
          <el-table-column prop="public_license" label="行政许可信息">
            <template slot-scope="{row}">
              <el-button
                v-if="row.public_license > 0"
                v-on:click="$router.push({path: `/corporateCreditFile/adminLicenseInfo`,query: {creditCode:row.creditCode}})"
              >行政许可信息</el-button>
              <el-button
                v-else
                disabled
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;无&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="public_punish" label="行政处罚信息">
            <template slot-scope="{row}">
              <el-button
                v-if="row.public_punish > 0"
                v-on:click="$router.push({path: `/corporateCreditFile/adminPenaltyInfo`,query: {creditCode:row.creditCode}})"
              >行政许可信息</el-button>
              <el-button
                v-else
                disabled
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;无&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</el-button>
            </template>
          </el-table-column>
          <el-table-column label="评级信息">
            <template slot-scope="{row}">
              <span
                class="rating-action"
                v-on:click="$router.push({path: `/corporateCreditFile/ratingInfo`,query: {creditCode:row.creditCode}})"
              >{{row.nowGrade}}</span>
            </template>
          </el-table-column>
          <el-table-column label="三品一标认证" width="200">
            <template slot-scope="{row}">
              <el-button
                v-on:click="$router.push({path: `/corporateCreditFile/threeProduction`,query: {creditCode:row.creditCode}})"
              >三品一标</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-container>
      <div class="pageBox">
        <pagination
          v-show="total > 0"
          :total="total"
          :page.sync="page.pageIndex"
          :limit.sync="page.pageSize"
          @pagination="getList"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Pagination from "@/components/common/pagination";
import Request from "../../services/api/request.js";
import Auth from "@/services/authentication/auth.js";

export default {
  name: "creditRating",
  components: { Pagination },
  data() {
    return {
      township: [{ id: 0, name: "全部" }],
      publicOptions: [
        { id: 0, name: "全部" },
        { id: 1, name: "有" },
        { id: 2, name: "无" }
      ],
      currTown: 0,
      public_license: 0,
      public_punish: 0,
      page: {
        pageIndex: 1,
        pageSize: 20
      },
      listLoading: true,
      bTypes: 0,
      status: 0,
      total: 0,
      tableData: [],
      companyProduction: [],
      gradData: [],
      loggedinUserType: null
    };
  },
  mounted() {
    this.getTown();
    this.getList();
    this.getCompanyProduction();
  },
  created() {
    this.loggedinUserType = Auth().user().attrs.userType;
  },
  methods: {
    rowIndex({ row, rowIndex }) {
      row.rowIndex = rowIndex;
    },
    onSelectPubLicense() {
      this.getList();
    },
    onSelectPubPunish() {
      this.getList();
    },
    getCompanyProduction() {
      Request()
        .get("/api/company_production/name")
        .then(response => {
          this.companyProduction = response;
        })
        .catch(error => {
          console.log(error);
        });
    },
    getTown() {
      Request()
        .get("/api/town/all")
        .then(response => {
          this.township = this.township.concat(response);
        })
        .catch(error => {
          console.log(error);
        });
    },
    /* eslint-disable */
    getList(update = false) {
      this.listLoading = true;
      Request()
        .get("/api/company_production/all", {
          companyType: this.bTypes,
          approvalStatus: this.status - 1,
          pageNo: this.page.pageIndex - 1,
          pageSize: this.page.pageSize,
          townId: this.currTown
        })
        .then(response => {
          var tmpData = response.data;
          if (this.public_license == 1) {
            tmpData = tmpData.filter(function(licesnse) {
              return licesnse.public_license > 0;
            });
          } else if (this.public_license == 2) {
            tmpData = tmpData.filter(function(licesnse) {
              return licesnse.public_license == 0;
            });
          }
          if (this.public_punish == 1) {
            tmpData = tmpData.filter(function(punish) {
              return punish.public_punish > 0;
            });
          } else if (this.public_punish == 2) {
            tmpData = tmpData.filter(function(punish) {
              return punish.public_punish == 0;
            });
          }
          this.tableData = [];
          let indexItem = 0;
          tmpData.map(item => {
            let gradeArrayName = "credit_grade_data_" + indexItem;
            this.getNowGrade(response[gradeArrayName]).then(res => {
              item.nowGrade = this.getGradeString(res);
              this.tableData.push(item);
              this.total = this.tableData.length;
            });
            indexItem++;
          });
          this.total = this.tableData.length;
          setTimeout(() => {
            this.listLoading = false;
          }, 0.5 * 1000);
        })
        .catch(error => {
          console.log(error);
          this.tableData = [];
          this.srcData = [];
          this.total = 0;
          setTimeout(() => {
            this.listLoading = false;
          }, 0.5 * 1000);
        });
    },
    /* eslint-enable */
    filterCompnay(credit) {
      let company = this.companyProduction.find(x => x.creditCode === credit);
      if (company) {
        return company.companyName;
      } else {
        return "";
      }
    },
    async getNowGrade(creditCode, gradeArray) {
      let nowGrade = "";
      if (!gradeArray || !gradeArray.length) {
        nowGrade = "";
      } else {
        nowGrade = gradeArray.pop().nowGrade;
      } 
      return nowGrade;
    },
    // getGrade(dataTable) {
    //   let strGrade = "";
    //   Request()
    //     .get("/api/company_credit_grade/all", {
    //       approvalStatus: this.status - 1,
    //       creditCode: dataTable.creditCode,
    //       pageNo: this.page.pageIndex - 1,
    //       pageSize: this.page.pageSize,
    //       townId: this.currTown
    //     })
    //     .then(response => {
    //       this.gradData = response;
    //       let nSIze = this.gradData.length;
    //       strGrade = this.getGradeString(this.gradData[nSIze - 1].nowGrade);
    //       dataTable.nowGrade = strGrade;
    //     })
    //     .catch(error => {
    //       console.log(error);
    //       return "";
    //     });

    //   return dataTable.nowGrade;
    // },
    getGradeString(grade) {
      let strGrade = "";
      switch (grade) {
        case "A":
          strGrade = "A级（守信）";
          break;
        case "B":
          strGrade = "B级（基本守信）";
          break;
        case "C":
          strGrade = "C级（失信）";
          break;
        default:
          strGrade = "A级（守信）";
      }
      return strGrade;
    },
    order(row) {
      return this.page.pageSize * (this.page.pageIndex - 1) + row.rowIndex + 1;
    }
  }
};
</script>
<style lang="scss" scoped>
@import "./corporateCreditFile.scss";
</style>