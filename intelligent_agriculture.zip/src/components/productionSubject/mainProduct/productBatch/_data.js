
export default [
  {
    id: "1",
    batchName: "2017-11-12 17:09:52 银针，银针，特级",
    batchNumber: 'FDBC201711121709520110201',
    operation: ["2017-09-09采摘", "2017-09-09采摘", "2017-09-09采摘"],
    sales: "",
    attributeName: "萎凋方式",
    testReport: "",
  },
  {
    id: "2",
    batchName: "2017-11-12 17:09:52 银针，银针，特级",
    batchNumber: 'FDBC201711121709520110201',
    operation: ["2017-09-09采摘", "2017-09-09采摘", "2017-09-09采摘"],
    sales: "",
    attributeName: "萎凋方式",
    testReport: "",
  }
]
