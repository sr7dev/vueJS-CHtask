
export default [
  {
    id: "1",
    date: "2019-08-12",
    sample: '水蜜桃',
    testItems: "农药残留",
    testResults: "阴性",
    determination: "合格",
    testingStandard: "食品安全法",
    testingFacility: "无锡瑞美",
  }
]
