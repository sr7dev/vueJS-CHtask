
export default [
  {
    id: "1",
    productName: '银针',
    isExistOrganicProduct: "是",
    unitPrice: "200",
    placeOrigin: "福建福鼎点头镇",
    variety: "白茶",
    specification: "200克",
    rating: "特级",
  }
]
